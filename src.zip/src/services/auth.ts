import axios from "axios";

interface LoginCredentials {
  employeeCode: string;
  password: string;
}

interface LoginResponse {
  access_token: string;
  token_type: string;
}

export const login = async (credentials: LoginCredentials): Promise<LoginResponse> => {
  try {
    const response = await axios.post("/api/auth/login", credentials);
    return response.data;
  } catch (error) {
    throw error;
  }
};
